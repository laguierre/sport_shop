
import 'dart:ui';

const double kPadding = 10;
const kPrimaryColor = Color(0xFF162B4E);
final List <String> btnNamesText = [
  'All',
  'Nike',
  'Adidas',
  'Basket',
  'Football',
  'Sneakers',
];